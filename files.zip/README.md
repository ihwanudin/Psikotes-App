# psikotes.oncam.id

Sistem psikotes online multi-cabang LSI: IST, PAPI Kostick, RMIB, Kraepelin — skoring otomatis, laporan aspek 1–10 (Format Serbaindo, bilingual ID–JP), proctoring, pembayaran transfer manual + gateway, fee cabang.

Stack: Laravel · Inertia.js+React (peserta) · Filament/Livewire (admin/staf/psikolog) · PostgreSQL+RLS · Docker Compose (VPS) · object storage S3-compatible · Shared Drive (arsip) · WAHA/n8n · Xendit.

## Peta dokumen
| Baca | Untuk |
|---|---|
| SPEC.md | Spesifikasi fungsional (sumber kebenaran) |
| PANDUAN-EKSEKUSI.md | Urutan fase F0–F7 + gerbang |
| CLAUDE.md | Aturan kerja AI — dibaca otomatis Claude Code |
| SCORING_ALGORITHM.md | Semua logika skor (kanonik) — status draft/final per bagian |
| ARCHITECTURE / DATABASE_SCHEMA / API_CONTRACT / SECURITY | Teknis |
| TEST_PLAN / DEPLOYMENT / ADMIN_GUIDE / PRIVACY_POLICY / CHANGELOG | Operasional |

Mulai: `pnpm i` → salin `.env.example` → jalankan F0 (`PANDUAN-EKSEKUSI.md`). Jangan tulis kode aplikasi sebelum gerbang F0 lulus.
